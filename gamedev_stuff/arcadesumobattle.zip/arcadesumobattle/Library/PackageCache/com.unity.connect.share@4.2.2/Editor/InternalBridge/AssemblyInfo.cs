using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.Play.Publisher.Editor")]
